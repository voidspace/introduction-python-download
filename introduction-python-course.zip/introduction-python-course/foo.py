# foo.py
print(__name__)